// ✅ AUTO-LOGIN FOR DEMO (BRINGS BACK DR. RAM AFTER LOGOUT/REFRESH)
if (!localStorage.getItem("loggedDoctor")) {
  localStorage.setItem("loggedDoctor", "Dr. Ram");
}

// ✅ UPDATED PATIENT DATA (AARAV & RIYA)
localStorage.setItem("appointments", JSON.stringify([
  { user: "Aarav", doctor: "Dr. Ram", slot: "10:00" },
  { user: "Riya", doctor: "Dr. Ram", slot: "11:00" }
]));

// -------------------- Helpers --------------------
const SLOTS = [
  "09:00", "10:00", "11:00", "12:00",
  "14:00", "15:00", "16:00", "17:00"
];

function readJSON(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) || fallback;
  } catch(e) {
    return fallback;
  }
}

function writeJSON(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

// -------------------- TEMP DOCTOR DATA (FOR PROFILE) --------------------
const doctorData = {
  "Dr. Ram": {
    spec: "Cardiologist",
    hospital: "Apollo Hospital",
    phone: "9876543210",
    email: "drram@gmail.com"
  },
  "Dr. Anusha": {
    spec: "Gastroenterologist",
    hospital: "City Care Hospital",
    phone: "9123456780",
    email: "dranusha@gmail.com"
  }
};

// -------------------- State --------------------
const loggedDoctor = localStorage.getItem("loggedDoctor");
if (!loggedDoctor) {
  console.warn("No loggedDoctor found in localStorage.");
}

const WORK_KEY = `${loggedDoctor}_work`;
const BREAK_KEY = `${loggedDoctor}_break`;

// -------------------- DOM refs --------------------
const doctorNameEl = document.getElementById("doctorName");
const totalEl = document.getElementById("totalAppointments");
const patientTable = document.getElementById("patientTable");
const slotBox = document.getElementById("slotBox");

const workStartInput = document.getElementById("workStart");
const workEndInput = document.getElementById("workEnd");
const breakStartInput = document.getElementById("breakStart");
const breakEndInput = document.getElementById("breakEnd");

// ✅ PROFILE DOMs FROM YOUR HTML
const docSpecEl = document.getElementById("doctorSpec");
const docHospitalEl = document.getElementById("doctorHospital");
const docPhoneEl = document.getElementById("doctorPhone");
const docEmailEl = document.getElementById("doctorEmail");

// -------------------- Core render functions --------------------
function loadAppointments() {
  return readJSON("appointments", []);
}

function getDoctorAppointments() {
  const appts = loadAppointments();
  if (!loggedDoctor) return [];
  return appts.filter(a => a.doctor === loggedDoctor);
}

function renderDoctorHeader() {
  doctorNameEl.innerText = `Welcome, ${loggedDoctor || "Doctor"}`;
}

function renderDoctorProfile() {
  if (!loggedDoctor || !doctorData[loggedDoctor]) return;

  docSpecEl.innerText = doctorData[loggedDoctor].spec;
  docHospitalEl.innerText = doctorData[loggedDoctor].hospital;
  docPhoneEl.innerText = doctorData[loggedDoctor].phone;
  docEmailEl.innerText = doctorData[loggedDoctor].email;
}

function renderPatientList() {
  const doctorAppointments = getDoctorAppointments();
  patientTable.innerHTML = "";

  doctorAppointments.forEach(app => {
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${app.user}</td><td>${app.slot}</td>`;
    patientTable.appendChild(tr);
  });

  totalEl.innerText = doctorAppointments.length;
}

function isTimeInRange(time, start, end) {
  if (!start || !end) return false;
  return time >= start && time < end;
}

function renderSlots() {
  const doctorAppointments = getDoctorAppointments();
  const wk = readJSON(WORK_KEY, {});
  const br = readJSON(BREAK_KEY, {});

  if (wk.start) workStartInput.value = wk.start;
  if (wk.end) workEndInput.value = wk.end;
  if (br.start) breakStartInput.value = br.start;
  if (br.end) breakEndInput.value = br.end;

  slotBox.innerHTML = "";

  SLOTS.forEach(slot => {
    const span = document.createElement("span");
    span.innerText = slot;

    const booked = doctorAppointments.some(a => a.slot.startsWith(slot));
    const inWorkPeriod = wk.start && wk.end && isTimeInRange(slot, wk.start, wk.end);
    const inBreak = br.start && br.end && isTimeInRange(slot, br.start, br.end);

    if (booked) {
      span.className = "red";
      span.title = "Booked";
    } else if (inBreak) {
      span.className = "yellow";
      span.title = "Doctor Break";
    } else if (inWorkPeriod) {
      span.className = "green";
      span.title = "Available";
    } else {
      span.className = "green";
      span.title = "Outside working hours";
      span.style.opacity = "0.7";
    }

    slotBox.appendChild(span);
  });
}

function renderAll() {
  renderDoctorHeader();
  renderDoctorProfile();
  renderPatientList();
  renderSlots();
}

// -------------------- Save handlers --------------------
function saveWorkingHours() {
  const start = workStartInput.value;
  const end = workEndInput.value;
  if (!start || !end) {
    alert("Please select start and end times for working hours.");
    return;
  }
  writeJSON(WORK_KEY, { start, end });
  alert("Working hours saved!");
  renderSlots();
}

function saveBreakTime() {
  const start = breakStartInput.value;
  const end = breakEndInput.value;
  if (!start || !end) {
    alert("Please select break start and end times.");
    return;
  }
  writeJSON(BREAK_KEY, { start, end });
  alert("Break time saved!");
  renderSlots();
}

// -------------------- Logout --------------------
function logout() {
  localStorage.removeItem("loggedDoctor");

  alert("Logged out!");

  doctorNameEl.innerText = "Welcome, Doctor";
  totalEl.innerText = "0";
  patientTable.innerHTML = "";
  slotBox.innerHTML = "";

  docSpecEl.innerText = "---";
  docHospitalEl.innerText = "---";
  docPhoneEl.innerText = "---";
  docEmailEl.innerText = "---";
}

// -------------------- Cross-tab live update --------------------
window.addEventListener("storage", (e) => {
  if (e.key === "appointments" || e.key === WORK_KEY || e.key === BREAK_KEY) {
    renderAll();
  }
});

// expose save functions
window.saveWorkingHours = saveWorkingHours;
window.saveBreakTime = saveBreakTime;
window.logout = logout;

// -------------------- Initialize --------------------
document.addEventListener("DOMContentLoaded", () => {
  renderAll();
});

