/* =========================
   LOGIN DATA
========================= */

// USERS (Patients)
let users = [
  { username: "harini", password: "1234" },
  { username: "maya", password: "1111" },
  { username: "arjun", password: "2222" },
  { username: "sneha", password: "3333" }
];

// DOCTOR LOGIN DATA
let doctorsLogin = [
  { username: "Dr. Ram", password: "ram123", id: 1 },
  { username: "Dr. Anusha", password: "anu123", id: 2 },
  { username: "Dr. Karthik", password: "kar123", id: 3 },
  { username: "Dr. Priya", password: "pri123", id: 4 }
];

// ADMIN LOGIN DATA
let admins = [
  { username: "admin", password: "admin123" }
];

/* =========================
   DOCTOR PROFILE DATA
========================= */

let doctors = [
  {
    id: 1,
    name: "Dr. Ram",
    specialization: "Cardiologist",
    problem: "heart",
    experience: "12 years",
    qualification: "MBBS, DM (Cardiology)",
    hospital: "Apollo Hospital",
    fee: 700,
    timing: "10 AM - 5 PM",
    breakTime: "1 PM - 2 PM"
  },
  {
    id: 2,
    name: "Dr. Anusha",
    specialization: "Gastroenterologist",
    problem: "stomach",
    experience: "9 years",
    qualification: "MBBS, MD",
    hospital: "City Care Hospital",
    fee: 500,
    timing: "9 AM - 6 PM",
    breakTime: "1 PM - 2 PM"
  },
  {
    id: 3,
    name: "Dr. Karthik",
    specialization: "Dermatologist",
    problem: "skin",
    experience: "7 years",
    qualification: "MBBS, MD (Dermatology)",
    hospital: "Derma Plus Clinic",
    fee: 400,
    timing: "11 AM - 7 PM",
    breakTime: "2 PM - 3 PM"
  },
  {
    id: 4,
    name: "Dr. Priya",
    specialization: "General Physician",
    problem: "fever",
    experience: "10 years",
    qualification: "MBBS",
    hospital: "Sunrise Hospital",
    fee: 350,
    timing: "9 AM - 4 PM",
    breakTime: "12 PM - 1 PM"
  }
];

/* =========================
   PROBLEM → DOCTOR MAPPING
========================= */

let problemMap = {
  "stomach pain": "stomach",
  "gas": "stomach",
  "vomiting": "stomach",

  "chest pain": "heart",
  "heart problem": "heart",
  "bp": "heart",

  "skin allergy": "skin",
  "acne": "skin",
  "rash": "skin",

  "fever": "fever",
  "cold": "fever",
  "headache": "fever"
};

/* =========================
   SLOT TEMPLATE
========================= */

let defaultSlots = [
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "02:00",
  "03:00",
  "04:00",
  "05:00"
];

/* =========================
   SAMPLE APPOINTMENT DATA
   (FOR TESTING DASHBOARDS)
========================= */

let sampleAppointments = [
  { user: "harini", doctor: "Dr. Ram", slot: "10:00" },
  { user: "maya", doctor: "Dr. Ram", slot: "11:00" },
  { user: "arjun", doctor: "Dr. Anusha", slot: "12:00" },
  { user: "sneha", doctor: "Dr. Priya", slot: "09:00" }
];

// Load sample appointments only if none exist
if (!localStorage.getItem("appointments")) {
  localStorage.setItem("appointments", JSON.stringify(sampleAppointments));
}
